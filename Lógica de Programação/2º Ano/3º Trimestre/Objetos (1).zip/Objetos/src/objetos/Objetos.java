package objetos;

import java.util.ArrayList;
import javax.swing.JOptionPane;

public class Objetos {

    public static void main(String[] args) {
        //cadastraPessoa();
        cadastraAluno();
    }
    //public static void cadastraPessoa(){
    public static void cadastraAluno(){
        int qnt = Integer.parseInt(JOptionPane.showInputDialog
        ("Quantas pessoas deseja cadastrar?"));
        //ArrayList<Pessoa> lista = new ArrayList<>();
        ArrayList<Aluno> lista = new ArrayList<>();
        for(int i = 0; i < qnt; i++){
            String nome = JOptionPane.showInputDialog
            ("Digite o nome:");
            String matricula = JOptionPane.showInputDialog
            ("Qual é a matrícula de: "+nome);
            int idade = Integer.parseInt(JOptionPane.showInputDialog
            ("Digite a idade de: "+nome));
            String cpf = JOptionPane.showInputDialog
            ("Digite o CPF de: "+nome);
            Aluno a = new Aluno(nome,matricula, idade, cpf);
            lista.add(a);
        }
        for(Aluno a:lista){
            JOptionPane.showMessageDialog(null,"Nome: "+a.getNome()+
             "\nIdade: "+a.getIdade()+"\nCPF: "+a.getCpf()+"\nMatricula: "+a.getMatricula());
        }
    }
 }
